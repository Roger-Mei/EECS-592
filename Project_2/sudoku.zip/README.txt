Tic-tac-toe:
The "tictactoe.py" plays the tictactoe game. Please view the output from command line.
To run this code. Please input :
python3 tictactoe.py seed_number
in your command line.

Sudoku:
The sudoku.py includes the main sudoku solver. It should read in a file called "suinput.csv". 
If you want to check the result in the command line (Highly recommended), please uncomment the visualize(CSP) line. 
To run this file, you should first create an empty csvfile whose name is "suoutput.csv"!!!
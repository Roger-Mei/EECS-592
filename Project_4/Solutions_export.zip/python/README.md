# EECS 592: Project 4

Matthew Romano

### Assumptions
All variables are Boolean

### Running

`python enumeration.py`